var mongoose = require('mongoose');
var dbmodel = require('./dbmodel');

var Driver = module.exports = {};

Driver.init = function(database) {
	this.dburi = 'mongodb://localhost/' + database;
	this.mongoose = mongoose;
	this.db = null;
	this.global = {};
	this.global.users = 0;
	this.Schema = dbmodel.Schema;
	this.Create = dbmodel.Create;
	this.Find = dbmodel.Find;
	this.Update = dbmodel.Update;
	return this;
};

Driver.connect = function(callback) {
	this.mongoose.connect(this.dburi);
	this.db = this.mongoose.connection;
	this.db.on('error', function(err) {
		console.log(err);
	})
	.once('open', callback);
	return this;
};

Driver.close = function() {
	this.db.close();
	return this;
};

Driver.find = function(schema, options, callback) {
	schema.find(options, callback);
	return this;
};
