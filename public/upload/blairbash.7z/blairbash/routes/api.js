var express = require('express');
var app = express();
var db = require('./dbdriver');

var apiAgent = function(req, res) {
	var query = (req.query);

	switch (req.param('type')) {
		case 'submit':
			delete query['type'];
			process.stdout.write('Quote Submit: ');
			console.log(query);
			db.Create.Quote(query, function(err, quote) {
				if (err)
					return console.log(err);
				res.end(JSON.stringify(quote));
			});
			break;
		case 'retrieve':
			delete query['type'];
			process.stdout.write('Quote Retrieve: ');
			console.log(query);
			var dataQuery = {};
			if (req.param('selection') == 'range')
				dataQuery.id = {$gte: req.param('min'), $lte: req.param('max')};
			else
				!req.param('id') || (dataQuery.id = req.param('id'));
			db.Find.Quote(dataQuery, function (err, quote) {
				if (err)
					return console.log(err);
				res.end(JSON.stringify(quote));
			});
			break;
		default:
			res.end('Unsupported Request');
			break;
	}
};

app.get('/', apiAgent);

module.exports = app;
