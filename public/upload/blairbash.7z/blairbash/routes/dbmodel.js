var mongoose = require('mongoose');

var Schema = module.exports.Schema = {};
var Create = module.exports.Create = {};
var Find = module.exports.Find = {};
var Update = module.exports.Update = {};

Schema.Number = (mongoose.model('Number', mongoose.Schema({
	key: String,
	value: Number
})));

Schema.String = (mongoose.model('String', mongoose.Schema({
	key: String,
	value: String
})));

Schema.Quote = (mongoose.model('Quote', mongoose.Schema({
	id: Number,
	content: String,
	info: String,
	tags: Array,
	activity: Number,
	positiveActivity: Number,
	timestamp: Date
})));

Create.Number = function(options, callback) {
	Schema.Number.create({
		key: options.key || '',
		value: options.value || 0
	}, function(err, number) {
		if (callback)
			callback(err, number);
	});
};

Create.String = function(options, callback) {
	Schema.Number.create({
		key: options.key || '',
		value: options.value || ''
	}, function(err, string) {
		if (callback)
			callback(err, string);
	});
};

Create.Quote = function(options, callback) {
	Find.Number({
			key: 'quotes'
		}, function(err, quotes) {
		quotes = quotes[0];
		Schema.Quote.create({
			id: options.id || (quotes.value + 1),
			content: options.content || '',
			info: options.info || '',
			tags: options.tags || [],
			activity: options.activity || 0,
			positiveActivity: options.positiveActivity || 0,
			timestamp: options.timestamp || Date.now()
		}, function (err, quote) {
			if (callback)
				callback(err, quote);
			Update.Number({
				key: 'quotes'
			}, {
				value: quotes.value + 1
			}, {

			}, function(err) {
				console.log(err || ('Quote ' + (quotes.value + 1) + ' Store'));
			})
		});
	});
};

Find.Number = function(options, callback) {
	Schema.Number.find(options, function(err, number) {
		if (callback)
			callback(err, number);
	});
};

Find.String = function(options, callback) {
	Schema.String.find(options, function(err, string) {
		if (callback)
			callback(err, string);
	});
};

Find.Quote = function(options, callback) {
	Schema.Quote.find(options, function(err, quote) {
		if (callback)
			callback(err, quote);
		if (!err)
			return quote;
	});
};

Update.Number = function(options, update, controls, callback) {
	Schema.Number.update(options, update, controls || {}, callback);
};

Update.String = function(options, update, controls, callback) {
	Schema.String.update(options, update, controls || {}, callback);
};

Update.Quote = function(options, update, controls, callback) {
	Schema.Quote.update(options, update, controls || {}, callback);
};
