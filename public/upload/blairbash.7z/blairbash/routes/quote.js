var express = require('express');
var router = express.Router();
var db = require('./dbdriver');

router.get('/:id', function(req, res) {
	db.Find.Quote({
		id: req.param('id')
	}, function(err, quote) {
		if (err)
			console.log(err);
		res.render('quote', {
			title: 'Blairbash',
			quote: quote[0] || {
				content: 'Does not exist'
			}
		});
	});
});

module.exports = router;
