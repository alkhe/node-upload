'use strict';
var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/test-blairbash');
var db = mongoose.connection;
db.on('error', function(err) {
	console.log('Connection error: ' + err);
})
	.once('open', function() {

		var Schema = {};

		Schema.Number = (mongoose.model('Number', mongoose.Schema({
			key: String,
			value: Number
		})));

		Schema.String = (mongoose.model('String', mongoose.Schema({
			key: String,
			value: String
		})));

		Schema.Quote = (mongoose.model('Quote', mongoose.Schema({
			id: Number,
			content: String,
			info: String,
			tags: Array,
			activity: Number,
			positiveActivity: Number,
			timestamp: Date
		})));

		Schema.Quote.remove({}, function() {
			Schema.Quote.find(function(err, data) {
				console.log(data);
			});
		});

		Schema.Number.remove({}, function() {
			Schema.Quote.find(function(err, data) {
				console.log(data);
			});
		});

		Schema.String.remove({}, function() {
			Schema.Quote.find(function(err, data) {
				console.log(data);
			});
		});

		Schema.Number.create({
			key: 'quotes',
			value: 0
		}, function() {
			//console.log('[]');
			Schema.Number.find({},
				function(err, data) {
				console.log(data);
			});
		});

		/*
		Schema.String.create({
			key: 'quotes'
		}, function() {

		});
		*/

	});

