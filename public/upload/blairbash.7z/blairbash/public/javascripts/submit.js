$(document).ready(function() {
	var content = $('#content'),
		info = $('#info'),
		tags = $('#tags'),
		submitQuote = $('#submitQuote'),
		submit = function(con, inf, tag) {
			$.ajax({
				url: '/api',
				data: {
					type: 'submit',
					content: con,
					info: inf,
					tags: tag
				}
			})
			.done(function(data) {
				console.log(data);
			});
		};

	submitQuote.click(function() {
		submit(content.val(), info.val(), tags.val().split(/\s+/));
	});
});

