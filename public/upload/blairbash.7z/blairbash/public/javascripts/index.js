$(document).ready(function() {
	var header = $('.header'),
		header_buffer = $('.header-buffer');

	header_buffer.height(header.height());
});
